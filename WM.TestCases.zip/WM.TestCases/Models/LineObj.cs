﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WM.TestCases
{
    public class lineObj
    {
        public string AreaCode { get; set; }
        public string LineNo { get; set; }
        public string PipingClass { get; set; }
        public string Service { get; set; }
        public string MainSize { get; set; }
        public string revision { get; set; }
        public string DrawingNo1 { get; set; }
        public string DrawingNo2 { get; set; }
        public string SheetNo1 { get; set; }
        public string SheetNo2 { get; set; }
    }
}
