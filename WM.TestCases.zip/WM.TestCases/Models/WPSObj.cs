﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WM.TestCases
{
    public class WPSObj
    {
        public string WPSName { get; set; }
        public string WPSCode { get; set; }
        public string PQR { get; set; }
        public string ThickFrom { get; set; }
        public string  ThickTo { get; set; }
        public string DIAFrom { get; set; }
        public string DIATo { get; set; }

    }
}
