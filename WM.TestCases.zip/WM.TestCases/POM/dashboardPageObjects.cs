﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.PageObjects;

namespace WM.TestCases
{
    class dashboardPageObjects
    {
        private IWebDriver _driver;
        public dashboardPageObjects(IWebDriver driver)
        {
            _driver = driver;
            PageFactory.InitElements(_driver, this);
        }

        [FindsBy(How= How.XPath, Using = "//*[@id='JointsHeader']")]
        public IWebElement pnlJointsStats { get; set; }


        //Data
        [FindsBy(How = How.XPath, Using = "//li[@id='li_Data']")]
        public IWebElement mnuData { get; set; }

        //Areas
        [FindsBy(How = How.LinkText, Using = "Areas")]
        public IWebElement mnuAreas { get; set; }

        //Lines
        [FindsBy(How = How.XPath, Using = "//*[@id='li_Data']/ul/li[2]/a")]
        public IWebElement mnuLines { get; set; }

        //WPS
        [FindsBy(How = How.XPath, Using = "//*[@id='li_Data']/ul/li[5]/a")]
        public IWebElement mnuWPS { get; set; }

        //Joints
        [FindsBy(How = How.XPath, Using = "//*[@id='li_Data']/ul/li[10]/a")]
        public IWebElement mnuJoints { get; set; }

        //Administration
        [FindsBy(How = How.XPath, Using = "//*[@id='li_Administration']")]
        public IWebElement mnuAdministration { get; set; }

        //System Definitions 
        [FindsBy(How = How.XPath, Using = "//*[@id='li_Administration']/ul/li[1]/a")]
        public IWebElement mnuSystemDefinitions { get; set; }



        public definitionsPageObjects openDefinitions()
        {
            mnuAdministration.Click();
            mnuSystemDefinitions.Click();
            return new definitionsPageObjects(_driver);
        }


        public areasPageObjects openAreas()
        {
            mnuData.Click();
            mnuAreas.Click();

            return new areasPageObjects(_driver);
        }

        public linePageObjects openLines()
        {
            mnuData.Click();
            mnuLines.Click();
            return new linePageObjects(_driver);
        }

        public wpsPageObjects openWPS()
        {
            mnuData.Click();
            mnuWPS.Click();
            return new wpsPageObjects(_driver);
        }
        public jointsPageObjects openJoints()
        {
            mnuData.Click();
            mnuJoints.Click();
            return new jointsPageObjects(_driver);
        }
    }
}
